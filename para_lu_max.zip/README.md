# Para Lu 🌷

Página web romántica de una sola página, sin dependencias externas.

## Uso

1. Sube `index.html` a la raíz de un repositorio público en tu GitHub personal.
2. Ve a **Settings → Pages**.
3. Selecciona **Deploy from a branch**.
4. Elige `main` y `/ (root)`.
5. Guarda y abre la URL que genere GitHub Pages.

## Compatibilidad

- Android y navegadores móviles modernos.
- Escritorio con mouse o touchpad.
- Respeta `prefers-reduced-motion`.
- El botón **No** usa `visualViewport` para mantenerse dentro del área visible.
